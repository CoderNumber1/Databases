<html>
	<head>
		<title>Example 2</title>
	</head>
	<body>
		<?
			$website = "http://www.bitafterbit.com";
			echo ("<br>Surf to: $website");
			echo ('<br>Surf to: $website');
		?>
	</body>
</html>