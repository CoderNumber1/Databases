<html>
	<head>
		<title>Example 1</title>
	</head>
	<body>
		<?
			echo ("<h1>Hello World!</h1>");
		?>
	</body>
</html>